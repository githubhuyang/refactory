def search(x, seq):
    y = 0
    for z in seq:
        if x > z:
            y += 1
    return y

  
            

